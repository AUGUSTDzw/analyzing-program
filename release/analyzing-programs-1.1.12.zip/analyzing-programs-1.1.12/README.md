# analyzing-programs

给 ABAP/SAP 源码生成结构化中文分析报告：固定六节结构，每个引用源码的代码块后面
跟三层（做什么 / 为什么 / 风险与改进），问题按 P0–P3 分桶。

## 目录

```
SKILL.md                       规则本体（535 行）
scripts/report_qc.py           格式闸门：逐条列出违规位置，可自动修两类
scripts/evaluate.py            内容评分：对冻结缺陷清单判分，算召回与错误论断
scripts/docgen.py              文档生成：源码抽成类 / FORM / 函数 / 表 / 调用的清单
scripts/abap_deps_analyzer.py  依赖分析：对照自带的 abaplint-deps 查标准对象引用
references/example-report.md   完整范例（真实报告，逐字未改，闸门零缺陷）
references/large-inputs.md     大输入的实测行为（观察，不是规则）
references/README.md           范例的出处与局限
evals/README.md                缺陷参考的格式、用法与边界
evals/*.defects.json           127 条缺陷 / 7 个真实源码
schemas/report-contract.json   闸门规则与 skill 教学锚点的唯一来源
tests/*.py                 仓库内的验证套件，**不随包发布**（见「跑一遍」）
```

## 三件工具各管什么

| 工具 | 回答 | 答不了 |
|---|---|---|
| `report_qc.py` | 形状对不对：六节、三层、四桶、无行号、Mermaid 可渲染、密度 | 分析是否正确、漏没漏 |
| `evaluate.py` | 对着冻结清单，报告漏了几条、有几条错误论断 | 判分本身对不对 |
| `tests/test_skill.py` | 上面两个还灵不灵，尤其是**拒绝**路径与退出码 | — |
| `tests/test_contract_drift.py` | 契约里的每条规则 SKILL.md 教了没有，反之亦然 | — |
| `tests/test_gate_enforcement.py` | 闸门放过的报告逐条复现，先记录现状再断言应有的行为 | — |
| `tests/test_fidelity_tiers.py` | 新旧分类口径是否等价：不泄漏、不误伤 | — |
| `tests/test_docgen_deps.py` | docgen 与依赖分析器的解析器、锚点与命令行是否还灵 | — |

**判分是模型工作。** `evaluate.py` 的 `tasks` 子命令把问题打印出来让判分者逐条回答，
`score` 与 `compare` 是确定性的。它保证参考完整、聚合正确、缺项不能冒充完整；
它不保证判分是对的。

## 跑一遍

包里的东西，装到哪儿都能跑：

```bash
python scripts/report_qc.py REPORT SOURCE                # 格式；报告须 .md/.markdown，其余当源码
python scripts/report_qc.py --fix REPORT SOURCE -o OUT   # 格式 + 自动修两类
python scripts/evaluate.py tasks  --defects evals/zcl_fi_toolkit.defects.json
python scripts/evaluate.py score --defects D.json --verdicts MY.json
python scripts/evaluate.py compare --defects D.json --a V1.json --b V2.json
```

`score` / `compare` 上还有一个 `--legacy`：豁免引文校验，给没有 `evidence.quote` 的旧判分文件用。加了它就跳不过去——不带它时缺引文会被拒，带它时判分照做但 `WARNING  --legacy: citations were not verified` 会印在输出里。

验证套件在仓库里跑。`tests/` 不随包发布，安装包里没有这五个文件：

```bash
python tests/test_skill.py              # 174 项
python tests/test_contract_drift.py     # 123 项，契约 <-> SKILL.md <-> 闸门 三方对齐
python tests/test_gate_enforcement.py   # 25 项，闸门执行漏洞探针
python tests/test_fidelity_tiers.py     # 7 项，改动前后口径是否等价
python tests/test_docgen_deps.py        # 95 项，docgen 与依赖分析器
```

合计 424 项。

**退出码是契约的一部分。** 所有模式在仍有缺陷时返回非零，包括 `--fidelity-only`
与 `--fix` —— SKILL.md 第 6 步让模型"重跑到干净为止"，那条循环只能靠退出码终止。
两个脚本都自己把 stdout 重配为 UTF-8：契约里的优先级桶标记是 emoji，
在默认 cp936 的 Windows 控制台上打印会抛 `UnicodeEncodeError`，
而且是从缺陷循环里抛的，诊断信息会被 traceback 顶掉。
Windows 上不需要设 `PYTHONUTF8`。

**为什么 `tests/` 不进包。** 每个 suite 都用
`HERE = dirname(abspath(__file__))` 往上数出仓库根，再去根下找同级的
`Test-source/` 与 `analyzing-programs-workspace/`——那两棵树明确不随 skill 发布
（`analyzing-programs-workspace/` 是上游开发线快照）。所以放进包里只会得到一个
跑不起来的东西：装到 `~/.agents/skills/` 之后五个 suite 都会在第一个 fixture 上
`FileNotFoundError`，`test_skill.py` 是 168 过 1 挂（挂的是 `the exemplar's
source is present`，它需要 `Test-source/real/` 里那份 `zbc_show_error_log`）。
1.1.10 是把这句话写进 README；1.1.11 是直接不把它发出去——包里剩下的每件东西
都能在装好的位置跑通，这句话才成立。`release/pack.py` 里有一个 `NOT_SHIPPED`
名单加一条 `CRITICAL` 守卫，后者保证误把 `schemas/` / `scripts/` /
`references/` / `evals/` 填进排除名单时打包会直接断言失败，而不是悄悄少发。
`references/README.md` 与 `evals/README.md` 里有两处指向 `tests/` 的交叉引用，
那是指向仓库内的套件，读发布包的人找不到很正常，不删。

**四种「没检查」的样子，其中一种仍然和通过只差一行 note。** 下表全部实测，
SKILL.md「闸门输出」一节照抄：

| 情况 | 实际输出 | 退出码 |
|---|---|---|
| 形状模式不传源码 | `PASS <报告名>` + `note  no source recognised, so density, fidelity, fix-mislabel, authz and ext-asset were not run (pass the ABAP file after the report)` | `0` |
| 源码路径不存在 | `error no such source: ...`，一个字都没查 | `2` |
| 报告路径不存在 | `error no such report: ...` | `2` |
| 给了多于一个源码 | `error more than one source: ...`（不是静默取最后一个） | `2` |
| 报告存成非 `.md` / `.markdown` | `error no report path: ...` —— 闸门认为你没给报告 | `2` |

所以：形状检查的 `0` 只能读作「形状对」，**看到那条 skip note 就等于五项诊断没跑**
（六项诊断里只有 `fix-lang` 不需要源码）。
这一版的闸门在源码路径写错时会**拒绝运行**而不是打印 PASS —— 上一版不是那样的，
上一版会照跑、照打印 `PASS`、零 note。这三条语义已经改过两轮，
全部记在 `schemas/report-contract.json` 里，闸门行为集中在 `gate_io` 段
（该段 4 个锚点，契约合计 23 个），
`test_contract_drift.py` 逐条查它们在不在 SKILL.md 里。

自动修只做两类改不动的判断：位置标签写成行号 → 改成最近的前置构造名；
Mermaid 标签里的裸 `<` `>` `#` → 改成全角。三层缺失**只报位置不修**，
因为那需要判断后面的散文本该属于哪一层，猜错会把风险论述标成"做什么"。

## 两条实测边界

- **20 条缺陷的配对比较分辨不出小效应。** 低于约 30 个百分点记作**未测量**。
  同一个 skill 同一文件重判，召回在 0.625–0.700 之间动。
- **大输入下预期一次任务写不完 —— 但这条只对 FI toolkit 那批成立。**
  两个数必须带协议标签读，**不能并列**：

| 观测 | 输入 | 协议 | 结果 |
|---|---|---|---|
| `references/large-inputs.md` | FI toolkit，约 1700 行、18 个子程序 | 更早的 harness、更早的 skill 版本 | 14 次派发完整 4/14（29%），其中 6 次静默、4 次截断 |
| 符合性探针 + 完成率第三、四轮 | `objects_program` 1597 行、`flow_logic` 1114 行 | 当前版本，**不要求额外交付物** | **9 份报告全部产出** |

第二个数只说明"这一类输入在当前版本下目前写得完"，**不构成完成率断言**。
而"失败都死在第三节内部"这句旧的概括已经不准确：FI toolkit 那 14 次里有
**6 次是静默**——什么都没产出，根本没走到第三节。失败有三种形态：
静默、截断、写完但变厚变薄。细节见 `references/large-inputs.md`。

## 能声明什么，不能声明什么

这一节限定交付范围，不是免责声明。原始数据在
`analyzing-programs-workspace/iteration-8/`（上游仓库，不随 skill 发布）。

### 先说版本：下面的数字不是出货版本的数字

iteration-8 的全部数字都是在 **`b8f84e8`**（162 行）上测出来的。
**出货版本是 `1.1.12`（536 行）。形状一致性有 n=3 的证据（见下，测于 1.1.5），**效果**未测出结论。**

版本谱系（每一版都已归档在 `release/`，digest 见 `release/SHA256SUMS`）。
`commit` 列是本仓库的 git id，**不是** zip 的 sha256——那是 `release/SHA256SUMS` 的事。
**1.1.0 之前的 12 行沿用了上游血统的 id，在本仓库解析不了**（`git cat-file -t` 报
Not a valid object name），那几行的行数只能从 `--follow` 找到的同源提交间接印证；
1.1.0 起每行都能直接 `git show`。

| 版本 | 行数 | commit | 改了什么 |
|---|---|---|---|
| `b8f84e8` | 162 | `b8f84e8` | **唯一被端到端测过的版本**，但没出货 |
| `718f5988` | 215 | `718f5988` | 加第 6 步修复轮、事实性纪律、范例引用 |
| `0dc9f17e` | 215 | `0dc9f17e` | 1.0.0。相对上一版只改了节标题与少量措辞 |
| `006719f8` | 250 | `006719f8` | 1.0.1。加「闸门输出」一节、粘贴源码先落盘、形状闸门拆成第 7 步 |
| `fac4d5a3` | 280 | `fac4d5a3` | **1.0.3**。闸门 / 评分脚本 / 契约 / 两个测试**整组**换成未发布开发线那份；SKILL.md 补 `fence`、`fix-mislabel`、密度与三层窗口的定义，并按新闸门的实测行为重写退出码一节 |
| `d3c55463` | 321 | `d3c55463` | **1.0.4**。纯文档：Mermaid HTML 子集例外、教 `--fix`、大输入章节指向 `references/large-inputs.md`、修三处事实陈述（22 个百分点改为只留方向并标注幅度未测量 / 转写错误归属改正 / 失败形态补上静默） |
| `9a013e47` | 325 | `9a013e47` | **1.0.5**。唯一一处闸门改动：`fix-mislabel` 的判据从「每条语句都在源码某处出现过」改成「整块逐字**连续**出现在源码里」。旧判据在九份真实报告上误报 5 次、全部是真改法；新判据 5 次全消，同时保留对真引用贴错围栏的检出（测试从 95 项增至 98 项，新增的负向用例就是"各行都存在但不相邻"这一例） |
| `5b1241c` | 357 | `5b1241c` | **1.0.6**。三处闸门修复 + 文档对齐。P0-1：忠实度不再对整行中文静默放行（`WRITE / '开始'.` 被当成点评跳过，注释与字面量里的中文仍是代码）；P0-1b：省略放行只认代码部分，注释里的 `...` 不再是后门；P0-2：规则集读不到时以退出码 `2` 拒绝运行（原来未捕获异常退 `1`，而 `1` 被 SKILL.md 定义为"查过了、有缺陷"）。SKILL.md 补齐与这三处对应的说法；契约补上 `gate_start_refuses_without_a_rule_set`（1.2.3 → 1.2.4）；frontmatter 加 `version` / `contract`；测试从 98 项增至 115 项，drift 从 104 项增至 105 项 |
| `5ff381c8` | 412 | `5ff381c8` | **1.0.7**。纯文档，零闸门改动，契约保持 1.2.4。两处来自另一台设备上的现场反馈：**三层渲染成一段**——「拆分步骤」一节推荐紧凑写法，而那个示例把三层写在连续三行上，CommonMark 视为同一段落；且它与自己的范例 `example-report.md`（三层之间有空行）矛盾。12 个三层标签行现已全部后随空行。**第一层太笼统**——`:224` 的要素清单本就在，但抽象规则句没有失败示例；现补三组「笼统→具体」对照（右侧全用范例里的真实句子）、四问自检清单，以及"每层至少点名一个源码对象"。两处都**没有**加检查器：闸门只数字符数，evals 的缺陷问的是源码不是写法 |
| `25b711cf` | 473 | `25b711cf` | **1.0.8**。契约 1.2.4 → 1.2.5（新增两条 note）。来自 `zvend` 留出集的失败样本：**报告点名了那个标识符，然后转身去写下一条**。with_skill 臂的加权召回 1.476、without_skill 臂 1.571，符号检验 4:5、p=1.0，这轮测不出差别；但 9 条分歧里形状一致——被判 partial 的七条都属"说对了事实、没推到读者能行动的位置"（硬编码位图写成"跨行业遗留"、授权写成"不做权限控制"）。据此改三处：第三层新增「每个具体标识符必须紧跟运行期后果」的硬规则 + 两组对照；禁掉「需核实」当结论句；新增 `authz` 与 `ext-asset` 两条 note，两条都只在报告没给出后果时才发。测试 115 → 129，drift 105 → 107。**这三条是假设不是测量结果** |
| `748f36b2` | 476 | `748f36b2` | **1.0.9**。契约 1.2.5 → 1.2.6。三处都是复审 1.0.8 时**量出来**的，不是读出来的。**报告不是 UTF-8 时闸门抛未捕获异常**——`report_qc.py` 有三处裸读报告，cp936 报告（中文 Windows 上编辑器"另存为"的默认结果）→ traceback + 退 `1`，而 `1` 被定义为"查过了、有缺陷"，与契约自己写的 "the one false reassurance this script is not allowed to give" 同形；现在与源码一样退 `2`，并加了 28 项测试覆盖三种模式 × 三种编码。契约 `exit_codes["2"]` 三处与实测不符：说"Every trigger prints a line starting with `error`"（实际无参数与 `--fix` 路径不足这两个例外不带 error）、无模式限定地列出 `source is empty`（实际只有 `--fidelity-only` 拒，形状模式打 note 后照常返回）、用字节数指认闸门（`24224` / `45523`，实际 53462，文件一改就过期）——改成按模式列并删掉字节数。**127 条缺陷里 91 条用行号做 anchor**，源码前面插一行空行、同一个 `L5` 就指向别的语句，而 `evaluate.py` 里 7 处 `anchor` 全是打印、一个都不校验；全部换成源码文本，三份缺陷集的 `source` 字段改成能打开的真实路径。测试 129 → 157，drift 107 不变 |
| `b70980f` | 358 | `b70980f` | **1.1.0**。闸门加五条强制检查：保真改 token 序列比对、标识符/字面量/数字被改过退 1，标点级差异仍 advisory；第五节问题行必须点名源码里存在的对象；三层正文不得三行相同；散文 U+FFFD 视为失败；要求 flowchart 与 sequenceDiagram 各一张。拆分 `report_qc.py` 为 `scripts/checks/` 下四模块。**闸门变严，效果未知** |
| `301500c` | 476 | `301500c` | **1.1.1**。四轮系统性代码审查，修复 24 个问题：错误处理（OSError 未捕获）、参数校验（报告/源码同文件、-o 路径有效性）、契约对齐（exit_codes 描述、defect_line_prefixes 缺失项）、测试覆盖（all_notes 排序固定）、缓存管理（_src_identities FIFO 驱逐）、注释修正。测试 315 项全过 |
| `52e35cf` | 476 | `52e35cf` | **1.1.2**。契约 1.3.0。十二轮质量审查、53 处修复、315 项测试全绿 |
| `57c75b5` | 494 | `57c75b5` | **1.1.3**。契约 1.3.0 → 1.3.1。两处闸门崩溃改成正经拒绝：`inventory()` 对事件块取 `group(1)` 抛 IndexError（事件块的 keyword 就是名字，ANCHORS 不给它 capture group），未捕获异常退 `1`——而 `1` 被定义为"查过了、有缺陷"，模型会去改不存在的缺陷；内部异常现统一走 `die()` 退 `2`。docgen 的正则锚在 `METHOD` 后的 `(` 上，六种写法里只有带参数的那种能匹配，类方法全被漏掉。`abaplint-deps` 随 skill 一起发布、按脚本自身位置解析（装好的 skill 里 CWD 从不是 skill 目录）。SKILL.md 补退出码表与资源索引。410 个文件 |
| `75fb895` | 494 | `75fb895` | **1.1.4**。契约 1.3.1 → 1.3.2，只补文档：`exit_codes["2"]` 里"规则集读不到"这条触发器是 1.2.4 加的，1.2.6 重写那段字符串时弄丢了措辞，而它的兄弟键 `gate_start_refuses_without_a_rule_set` 一直活着——只读那张平铺表的读者已经看不到四个启动期拒绝里最早的一个。闸门行为与 1.3.1 完全一致。同批修换行符：`*.txt` / `*.js` / `*.xml` 补进 `.gitattributes`，八个 blob 重新归一化成 LF（`.gitattributes` 管不了已经提交的 blob，而 `git status` 归一化后一直读成干净），发布目录标成 `-text` 冻结以免 git 重编码破坏与 zip 的逐字节一致；`pack.py` 断言 `ships_with` 并打印与上一版的布局差异 |
| `37ea6bd` | 494 | `37ea6bd` | **1.1.5**。docgen 四处解析缺陷 + 第五个测试套件，契约不动（1.3.2）。`_find_block_end` 要求 `ENDMETHOD` 后面跟子程序名，而 ABAP 允许但不要求带名字，于是什么都不匹配、所有块都跑到文件末尾、`end` 对每个子程序都相同；`CALL FUNCTION` 的名字从 `[A-Z0-9_]` 取，漏掉带引号的 `CALL FUNCTION 'Z_BC_LOG'`——ABAP 里最常见的那种；`USING` 被 `.*?` 组进 FORM 正则，永远匹配空，FORM 从不报参数；内部表过滤用大小写敏感的 `startswith`，`lt_tab` / `ws_data` 被当成数据库表；锚点用 `^\s*` 缩进而 `\s` 也能跨换行，被空行隔开的子程序锚点早一行。新增 `tests/test_docgen_deps.py`（67 项）覆盖 docgen 与 `abap_deps_analyzer` 的解析器、锚点与命令行——写它才把这五处挖出来 |
| `74944da` | 494 | `74944da` | **1.1.6**。契约不动（1.3.2）。**分析器八处修复**：`--deps` 锚定脚本自身位置而非 CWD；类型引用先减去本地声明的类型名；`unknown_*` 改名 `unresolved_*` 并降为 `info`（「不在随包桩库里」不等于「SAP 里没有」）；补冒号形 `PERFORM` / `METHOD` 与类内裸调用、取标识符前先剥行内注释、每次 `analyze()` 复位状态、修 `->+` / `=>+` 的自身回归、支持 ALV 回调的字符串字面量。`tests/test_docgen_deps.py` 67 → 95，含一个「decoy CWD 放同名 deps 目录」的负向用例。**范例报告过不了自己的闸门**：`row-src` 只在传了源码时才跑，而守护它的两个测试都不带源码，§5 里 P2-3（只有 `+1` / `MIN/MAX`）、P2-4（无拉丁标识符）、P2-5（只有 `PERFORM` / `ENDFUNCTION`，均在关键字排除表内）、P3-2（只有源码外的 `c05_abap_unit`）四行被自己的规则判死——带源码跑是 exit 1。四行各补一个真实源码对象名，exit 0；`test_skill.py` 加一项带源码跑，drift 的变异探针原来同样传不出源码，现在在范例上专门跑 `row-src` 并带负向对照。168 → 169，121 → 123。**闸门文档三处与实测不符**：退出码表只列了契约 15 个缺陷前缀中的 8 个、`--fidelity-only` 输出格式写错（实际先打 `SUBSTANT` / `PUNCT-` 分级行）、退出码 `2` 的触发条件漏了「报告与源码同一文件」及 `--fix` 的三个输出路径拒绝 |
| `aa609d5` | 513 | `aa609d5` | **1.1.7**。契约不动（1.3.2）。四处 SKILL.md 措辞修复 + 一处索引说明，全部来自**在两个真实程序上跑 skill 的实测**，不是读出来的。**`enc` 在正文里零覆盖**：它在退出码表里，但 495 行里既没有 `enc` 也没有 U+FFFD / 替换字符 / 乱码——撞上的写作者不知道改什么，更不知道修法是从源文件重新另存 UTF-8、而不是删掉替换字符。**SKILL.md 有一条事实错误**：说两条 note「都只在报告没给出后果时才发」，但只有 authz 有消音门槛，`ext_asset_note` 只要源码里有一个位图/图标字面量就必然发（它自己的 docstring 就是这么写的）。authz 的门槛本身是个十词正则，写作者完全没有可能看见，SKILL.md 现在把它列出来了。第 5 步补一个预检：这两条 note 问的东西第 6、7 步补不上——那两步不许动分析，`--fix` 也只修 `ln` 与 `mm`——必须收笔前就写进去。`references/abap-syntax` 自称一份资源，实际是上游约 30 份 cheat sheet 里的 8 份，其内部 13 处交叉引用指向从未收录的兄弟文件；索引现在写明这一点，否则 SKILL.md 一边让人「查这里」、一边禁止「凭记忆」，落到中间的题就无路可走 |
| `51957ef` | 513 | `51957ef` | **1.1.8**。契约不动（1.3.2）。`abap-syntax` 从上游 SAP `abap-cheat-sheets` 收录第 9 份：`11_Internal_Tables_Grouping.md`（6794 B，照抄原文）。九份与上游 `main` 的 git blob SHA-1 逐一核对过、全数吻合——顺带量出一件与旧版同源的偏差：本仓库 `core.autocrlf=input`，上游 8 份 CRLF 结尾的 cheat sheet 进库时被归一化成 LF，发布包带的是归一化后的 blob（`11_...` 为 `cefecc33411f`），只有上游本来就是 LF 的 `27_Exceptions.md` 对得上；这是换行符归一化，不是内容改动，但拿包去核对的人会当成被改过，索引与契约现在都写明，免得误判。它补上的正是 1.1.7 记下的那个死角：SKILL.md 让人「查这里」，同时禁止「凭记忆」，而 `references/README.md` 明说目录里没有的语义就没有——落到这两句中间的主题没有合法路径可走。`LOOP AT ... GROUP BY` 就是这个死角：它的行为由用哪一种绑定形式决定（代表式绑定与显式键绑定、`INTO` 附加项、`GROUP INDEX` / `GROUP SIZE`、`WITHOUT MEMBERS`、成员循环），而这层语义此前只存在于未收录的兄弟文件里。索引同步改为 9 份 / 上游 37 份，补上 Apache-2.0 出处与坏链清单；收录这份带进一个未收录兄弟链接 `02_Structures.md`、同时移出 `11_Internal_Tables_Grouping.md`，唯一缺失文件名数保持 12 个。闸门不读任何参考资料、只读契约，419 项检查全过 |
| `5336b94` | 535 | `5336b94` | **1.1.9**。契约 1.3.2 → 1.3.3，**文档修正、闸门行为一字未动**（`gate_io` 不被闸门读取，只被契约自身与 `test_contract_drift.py` 消费）。全部来自**实测对照**而非读代码：把范例报告复制出来篡改一句引用，形状模式实际打印 `SUBSTA   line 152 ...` 然后 `FAIL  (1 defect(s))` 再跟一条 note，退出 `1`——**四个说法因此作废**：exit 0 格说「没有形状缺陷」，实际还要「且无实质改写」（`report()` 只在 `not bad and not n_sub` 时退 0）；文档写分级名 `SUBSTANTIVE`，实际是 `tier[:6]` 截出的六个字符 `SUBSTA`；文档说 verdict 是末行，实际形状与 `--fix` 都在 verdict **之后**再打最多七条 note；文档说最多六条 note，实际 `all_notes()` 最多五条 + `fidelity_report()` 每级一条 = 七条。**authz 消音关键词表是照抄错版**：1.1.7 说"把十词正则列出来"，列出的十个词里有四个在正则里根本不存在（`任何人` / `其他用户` / `全部用户` / `并发权限` 一个都不命中），而真正会命中的 `任何能运行` / `任何可运行` / `任意用户` / `全体用户` / `数据权限` 一个都没写——写「其他用户」想让 note 消失，它不会消失。**其余修正**：`--fix` 零修复时不写 `.bak` 但仍原地写回；空源码在形状模式打两条 note 不是一条；崩溃那行补回被截掉的尾部；exit-2 表删掉「报告与源码同一文件」——那个守卫不可达，扩展名分流保证同一个路径不可能同时进两边；第 6/7 步补上当前目录必须是 skill 根目录（闸门不像 `abap_deps_analyzer` 那样自我定位）以及 `--help` 会被当成没给报告而退 `2`；`184 个对象` 定义清楚（191 个 `.abap` 文件里带 `.clas` / `.intf` / `.prog` 的子集）并补上未使用清单的已知假阳性（`SET HANDLER ... FOR` 注册的事件回调一律报「未使用」，实际都在跑）；Mermaid 补上方法引用 `->` / `=>` 的两种写法与「标签措辞是机械残留，不受『不许改分析』约束」。README 修掉三处互相矛盾的「出货版本」、358 → 535、22 → 23 个锚点、skip note 从三条诊断改回五条、缺陷清单 112 / 6 → 127 / 7（`ztest7.defects.json` 15 条此前两个索引都没列）、changelog 行数 `301500c` 358 → 476 与 `74944da` 495 → 494，并把列名从「sha256 前 7 位」改正为 `commit`（填的一直是 git id，且 1.1.0 之前的 12 行沿用了上游血统、在本仓库解析不了） |
| `510902c` | 535 | `510902c` | **1.1.10**。契约不动（1.3.3）：没有规则、阈值或 `gate_io` 行变化。发布 1.1.9 后把它装进 `~/.agents/skills/` 验了一遍才发现 README 说错了一句话——它把 `test_skill.py` 写成「自足检查，不依赖项目数据」，跑法一节也说「169 项，自足」。**从仓库根跑是这样，从安装位置跑不是。** 五个 suite 都用 `HERE = dirname(abspath(__file__))` 往上数出仓库根，再去根下找同级的 `Test-source/` 与 `analyzing-programs-workspace/`；这两棵树明确不随 skill 发布。实测（`C:\Users\DzwU\.agents\skills\analyzing-programs`）：`test_skill.py` 168 / 169，挂的那一项是 `the exemplar's source is present`——`row-src` 的守护检查，它必须拿到 `Test-source/real/` 里那份 `zbc_show_error_log`；另外四个在第一个 fixture 就 `FileNotFoundError`。**闸门本身与它的脚本在装好的位置是正常的**：同一位置 `python scripts/report_qc.py references/example-report.md <源码>` 退 `0`、打 `PASS`，实测。所以那 419 项是仓库侧的说法，README 现在把这个区别写明，而不是让拿到发布包的人以为能在消费它的那台机器上自验。契约只把 `ships_with` 挪到 1.1.10，`version` 留在 1.3.3，并记了一段说明为什么 |
| `f3eab57` | 535 | `f3eab57` | **1.1.11**。契约不动（1.3.3）。**上一版只是把「tests/ 在包里跑不起来」写进了 README，这一版直接把文件不发出去。** 理由很直白：包里不该有跑不通的东西。做法在 `release/pack.py` 加一个 `NOT_SHIPPED = ("tests/",)` 排除名单，打包时会打印 `excluded 5 repository-only file(s)`；旁边配一条 `CRITICAL` 守卫，把 `schemas/` / `scripts/` / `references/` / `evals/` 四个闸门真要读的目录列进去，误填一个就让打包直接 `AssertionError`，而不是悄悄少发。**契约和闸门一字未动**：五个 suite 从不被 `scripts/` 导入、也不读任何契约键，所以包小 5 个文件、行为完全一致。README 的目录表把 `tests/*.py` 一行改标为「不随包发布」，「跑一遍」拆成两段——包里装好就能跑的（`report_qc.py` / `evaluate.py` 五条），和只在仓库里跑的（五个 suite，419 项）。`references/README.md` 与 `evals/README.md` 里各有一处指向 `tests/` 的交叉引用，那是指向仓库侧套件的，读包的人找不到很正常，保留 |
| `8b4e8ca` | 536 | `8b4e8ca` | **1.1.12**。契约 1.3.3 → 1.3.4。**`--fix` 会给一份还没过闸门的报告发 `PASS`。** 量出来的：把范例报告复制出来，在一个代码块里给 `ENDFUNCTION.` 后面加一个词（形状完全没动），三个模式各跑一次——形状模式退 `1`，打 `SUBSTA   line 187 ...`、`FAIL  tampered.md  (1 defect(s))` 再跟一条 note；`--fidelity-only` 退 `1`，打 `FAIL  ...  (1 rewrite(s), 0 punctuation-only)`；`--fix` 退 **`0`**，打 `PASS`。**同一个报告，两个模式，两个不同的答案。** 原因在 `--fix` 分支：`fidelity_report()` 其实已经调了，但 `n_sub` 只喂给了 note，返回值是 `1 if left else 0`，`left` 是形状检查——**note 说了实话，退出码没听。** 而契约 `exit_codes["0"]` 本来就把「没有实质改写」写成了 `0` 的条件，所以契约和闸门说的是两件不同的事；第 6、7 步的循环只看退出码，循环会停在一个伪造的引用上。修法是让忠实度计算提到 verdict 之前、返回值改成 `1 if left or n_sub`；**note 的顺序一个字没动**，形状与 `--fix` 仍然 verdict 在前、note 在后（`notes_follow_the_verdict` 断言、`test_contract_drift.py` 钉住的就是这条）。verdict 顺手不再用一个数把两类混在一起，改成各数各的、都收在 `need the model` 上——`1 shape defect(s)`、`1 rewrite(s)`，或 ` and ` 连起来——一个总数会让读的人以为剩下的都能机械修掉。契约侧：`exit_codes["0"]` 补上「三种模式一致」，`exit_codes["1"]` 与 `conclusion_lines` 带上新措辞，`release._comment` 记下这个洞。SKILL.md 说明 `--fix` 一行分级行都不打，只用一条 note 报改写数，所以在那里 grep `SUBSTA` 是空的；README 补上 `score` / `compare` 的 `--legacy`；`test_skill.py` 加三条检查（形状模式失败、`--fix` 非零、`--fix` 不打 `PASS` 且指名 rewrite），169 → 174、合计 419 → 424 项 |

**契约版本与发布版本是两条独立的轴。** 契约 `version` 只在该文件自己的规则、
阈值或 `gate_io` 行变化时递增；发布版本对措辞和闸门行为的变化也递增。
所以两者只在契约恰好一起动的时候才相等——1.0.6 与 1.0.7 都带契约 1.2.4，1.0.8 带了 1.2.5，1.0.9 带了 1.2.6。这个映射记在契约的 `release.ships_with` 里，否则光看数字分不出
`1.2.6` 比 `1.0.9` 新还是旧。已部署的副本要能自报版本，
所以 frontmatter 也带 `version` 与 `contract` 两个字段。

| | b8f84e8（唯一端到端测过） | 748f36b2（出货） |
|---|---|---|
| 六节结构 / 三层格式 | 有 | 有（原样保留并扩充） |
| 第 6 步：写完后只修引文的独立一轮 | 无 | 有 |
| 事实性纪律章节 | **无** | 有 |
| 逐字符忠实、不展省略的代码块规则 | 部分 | 有 |
| 范例报告 / schemas / 评分脚本引用 | 无 | 有 |

**这张表比对的两个版本都已不是出货版本。** 写这张表时出货的是 `301500c`（1.1.1），
现在出货的是 `1.1.9`。这一栏过去一直停在一个更早的版本（1.0.5 / `9a013e47`），
而真正的出货版本一直在往前提——是版本表先更新、这处没跟上；到 1.1.1 时仍然没跟上，
现在对齐。表里的结论只对那两个版本成立。

对齐时实测过 1.0.5 与 1.0.9 两版的 SKILL.md：上表五项**全部仍在**，没有一项被
删改；1.0.5 之后新增的是「第 6 步」这类独立一轮、`fix-lang` 之外的第六条 note、
第三层的运行期后果硬规则，以及「禁把『需核实』当结论句」。所以

结构类规则从 `718f5988` 一路加到 `748f36b2`，是原样保留再加码的，下面的结构结论
**很可能**仍然成立；但严格说它是在 1.0.5 那次比对上量出来的。1.0.1、1.0.3、1.0.4
新增的内容只涉及闸门怎么判读与文字准确性，而那些说法是逐条对着
`scripts/report_qc.py` 的控制流**实测**出来的（见契约 `gate_io`），
**这不是效果证据**：符合性探针只证明模型照着做了，没有一轮测过照做之后报告会不会更好。

**`b8f84e8` 的效果类数字不属于它当时对着的那个出货版本，这件事没有变。**
写这张表时出货的是 `748f36b2`：它在结构一致性上有 n=9 的证据（见上一节），
在效果上**零证据**。现在出货的是 `1.1.9`，效果类**仍然零证据**——中间没有任何一版
补上这一块。

1.0.3 的闸门比 1.0.2 严在三处，且都是 1.0.2 的缺陷：源码路径写错时**拒绝运行**
（原来照跑并打印 `PASS`、零 note）、不带源码时**明说**三项诊断没跑（原来静默跳过）、
报告与源码按扩展名分工而不是靠 `.abap` 后缀猜（原来会把 `.txt` 源码当报告检查，
报出一堆不存在的缺陷）。这一版还多两类检查：`fence`（未闭合围栏会吞掉后续全部内容）
与 `fix-mislabel`（`abap-fix` 围栏里逐字出自源码的语句 = 贴错围栏的真引用）。

`b8f84e8` → `718f5988` 的对比（迭代 9）回答的正是"形状缺陷有没有减少"，
判据已在生成之前预注册在上游仓库 `analyzing-programs-workspace/iteration-9-plan.md`
（不随 skill 发布），只跑过 6 格 harness 验证、主判据未执行。
它**不**回答"分析是否更准确"。

### 能声明：报告结构一致性（b8f84e8）

六节结构、三层格式、优先级分桶的通过率 **0.980 vs 无技能 0.554（+42.6pp）**，
390 个配对单元上 McNemar 精确检验 **p = 5.55e-44**（170 个仅技能通过、
5 个仅基线通过）。本 skill 的价值主张就是这套结构，在 b8f84e8 上证据充分。

### 能声明：某一版出货字节产得出闸门合规的报告（`fac4d5a3`，n=9）

同一批派发里顺手产生的 **9 份报告**，全部在 `fac4d5a3`（1.0.3）下生成，
覆盖 `flow_logic`（1114 行）与 `objects_program`（1597 行）两份真实 ABAP。
九份**全部**经发布版闸门独立复核 `PASS`、退出码 0，展开密度 1.7–2.2（下限 0.5），
无 skip note。

**这条能支持什么**：`fac4d5a3` 这版字节能产出闸门合规的报告，n=9，真实源码
1114–1597 行。**它不覆盖 `748f36b2`** —— 从 1.0.3 到 1.0.9 闸门换了六次、SKILL.md
换了九版，中间没有任何一轮在这个 n=9 的批次上重跑过。1.0.9 的形状闸门与 1.0.3
是否产生同样结果，**未测**。

`fac4d5a3` 是 1.0.3。1.0.9/1.1.0 另有一批 n=3 的当前版本证据，**与这批不可合并**——
程序不同（`zvend.abap` 356 行 vs 这里的 1114–1597 行），派发条件不同（盲判 vs 单批）。
两批各自成立，凑不出更大的 n。

能说的还有一条更窄但能直接验的：1.0.9 自己那份 476 行的 SKILL.md 与
`references/example-report.md`，对 1.0.9 自己的闸门是 `PASS`、退出码 0，
`test_skill.py` 有两项专门守它（`the shipped example report still passes`
不带源码，`...against its own source` 带 `zbc_show_error_log` 源码）。
那是 n=1，但它是当前版本上唯一有的一条。

**这条不能支持什么**：

- **不能**支持任何"比不带 skill 更好"的结论 —— 单臂，无 baseline 对照。
  上面那个 +42.6pp 才是带对照的数，而它属于 `b8f84e8`。
- **不能**支持任何关于准确率、召回、缺陷发现率的断言。
- **不能**当完成率断言：这 9 份里有一批是刻意选了写得完的输入。

原始报告留在上游仓库 `analyzing-programs-workspace/`（不随 skill 发布），
对应两轮符合性探针与完成率第三、四轮。

### 1.1.0 的闸门变严了，效果仍然未知

1.1.0 给闸门加了五条强制检查：编造源码、问题行写空话、三层写同一句、删光 Mermaid、
散文坏字节，以前都能拿到 `PASS`。现在不能。

**这些改动不产生任何效果证据。** 它们改的是闸门能拦住什么，不是报告分析得好不好。
本 skill 的效果至今没有一轮测出过结论——最近一轮是 n=3 的盲判，结论是**不支持假设**
（两臂各 1/3 达到满档，10/12 vs 9/12），详见 `analyzing-programs-workspace/exp-1.0.9/`。

### 一条比召回数字更该先看的东西：这套缺陷集的区分度

1.0.9 那轮 n=3 盲判里，21 条缺陷有 **7 条（33%）在六次判定中完全一致**——两臂三次
都判 `yes`，或都判 `no`。剩下 14 条才有区分空间。

也就是说整体 recall 的差距（技能臂中位 1.476 / 基线臂 1.333）**主要由生成噪声决定，
不是由 skill 决定**。两臂的 yes 数序列是 [15,14,17] 与 [13,14,17]，几乎重合。

同一条缺陷在**同一臂的不同次里**可以判 `yes` 也可以判 `no`（D16 是 yes/yes/no，
D21 是 yes/yes/partial）。任何 n=1 的对比都在测噪声。这条应该排在所有召回数字前面读。

### 不能声明：分析更准确

对 77 条植入缺陷的召回，**技能 0.849 vs 基线 0.826（+2.3pp）**，
符号检验 9 高 / 8 低 / 9 平，**p = 1.000，不显著**。

评委层已经饱和：77 条里 **46 条（60%）两臂都得满分**，没有区分空间。
剩下 21 条能动的里技能赢 12 条、输 9 条 —— 方向上没输，
幅度却相互抵消到不可分辨。

### 站得住的失败：3 条（两次运行都更差）

| 缺陷 | 领域 | 技能 run1 / run2 | 基线 run1 / run2 |
|---|---|---|---|
| eval-4-D2 | 可编译性 | no / no | partial / yes |
| eval-9-D2 | CDS 语义 | partial / partial | yes / yes |
| eval-9-D6 | HTTP 资源 | partial / partial | yes / yes |

三条都是**只读源码就能判定**的缺陷：`RAISE EXCEPTION TYPE cx_sy_no_data`
（`CX_SY_NO_DATA` 是数据对象不是异常类，语法检查过不了）、CDS DDL 里写
`cast(sy-datum …)`（ABAP 运行时字段，DDL 里不成立）、多条早退分支都没调
`lo_client->close()`（连接不归还池）。它们不需要 SE38，不需要运行时语义。

值得注意的是 b8f84e8 明确写了「指出真实问题，不回避缺陷」。
所以这是**指令说了但没做到**的案例。成因没有定论 ——
2×2 的单元数不足以归因，这也是为什么该结论要留给下一轮去测。

### 不要当成失败：6 条只在单次运行上更差

eval-11-D2、eval-5-D5、eval-7-D1、eval-8-D1、eval-12-D2、eval-1-D4
各只有 1 次运行更差，另 1 次是平局或更好 ——
eval-7-D1 另一次是技能 yes、基线 partial，即技能更好。

同设计三次运行给过 0.605 / 0.645 / 0.737（SD 0.068）。
n=2 下单次差异与噪声不可分辨。**交付时按 3 条读，不按 9 条读。**

### 两条两臂全失：改 skill 无用

eval-10-D2（条件提交 `IF p_commit EQ 'X'` 导致后台作业整轮 `MODIFY marc`
随工作单元回滚，作业显示成功但一条都没落库）与 eval-13-D6（对**数值型**字段
用 `W = 12` 编辑掩码，且表头是硬编码文字而非可翻译文本元素）——
两臂两次运行全是 no。这是分析方法层的缺口，不是措辞问题。

### 所以怎么交付

按「结构化 onboarding 报告工具」交付，附本清单；**不要**按「分析更准确」交付。
后者没有正向证据，还有 3 处稳定的反向证据。

要支撑后者，得把评委清单的难度提到能区分两臂（46/77 饱和是根因）——
那不是采集更多数据能解决的：加缺陷条目无效已在当前取样下证明，
记录该次尝试的文件在上游仓库 `Test-result/noise-reduction-failed.md`
（不随 skill 发布）。


